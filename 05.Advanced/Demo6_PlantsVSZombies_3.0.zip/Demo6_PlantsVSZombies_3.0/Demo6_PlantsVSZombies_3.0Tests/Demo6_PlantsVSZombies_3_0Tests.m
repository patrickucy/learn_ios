//
//  Demo6_PlantsVSZombies_3_0Tests.m
//  Demo6_PlantsVSZombies_3.0Tests
//
//  Created by Patrick Yu on 8/11/14.
//  Copyright (c) 2014 MobileApp. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Demo6_PlantsVSZombies_3_0Tests : XCTestCase

@end

@implementation Demo6_PlantsVSZombies_3_0Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
