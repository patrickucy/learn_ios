//
//  TRSunFlower.h
//  Demo3_PlantsVSZombies
//
//  Created by Patrick Yu on 8/10/14.
//  Copyright (c) 2014 MobileApp. All rights reserved.
//

#import "TRPlant.h"
#import "TRViewController.h"

@interface TRSunFlower : TRPlant
@end
