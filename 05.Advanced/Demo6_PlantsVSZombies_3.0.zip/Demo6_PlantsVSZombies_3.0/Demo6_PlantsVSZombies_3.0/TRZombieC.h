//
//  TRZombieC.h
//  Demo2_Zombie
//
//  Created by Patrick Yu on 8/9/14.
//  Copyright (c) 2014 MobileApp. All rights reserved.
//

#import "TRZombie.h"

@interface TRZombieC : TRZombie

@end
